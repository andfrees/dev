<template>
  <div class="mainDevice">
    <div class="col">
      <div class="row borderOut">
        <h2>sideDevice</h2>
        <div
          v-for="type of ['gray', 'primary', 'accent', 'danger', 'warning', 'info']"
          :key="type"
          class="row"
        >
          <div v-for="i in 5" :key="i" :class="`color-${type}-${i}00` " class="row color borderOut">
            <div class="color-preview" />
            <VueDropdown label="Settings" icon-left="settings" icon-right="keyboard_arrow_down">
              <VueSwitch icon="bookmark" v-model="boolean" class="extend-left">Bookmark</VueSwitch>
              <VueSwitch icon="build" v-model="boolean" class="extend-left">Build</VueSwitch>
              <VueDropdownButton icon-left="settings_backup_restore">Backup and Restore Settings</VueDropdownButton>
            </VueDropdown>
          </div>
        </div>
      </div>
    </div>
    <div class="col">
      <div class="row borderOut">
        <h2>drawDevice</h2>
        <div
          v-for="type of ['gray', 'primary', 'accent', 'danger', 'warning', 'info']"
          :key="type"
          class="row"
        >
          <div v-for="i in 3" :key="i" :class="`color-${type}-${i}00` " class="row color borderOut">
            <div class="color-preview" />
            <VueDropdown label="Settings" icon-left="settings" icon-right="keyboard_arrow_down">
              <VueSwitch icon="bookmark" v-model="boolean" class="extend-left">Bookmark</VueSwitch>
              <VueSwitch icon="build" v-model="boolean" class="extend-left">Build</VueSwitch>
              <VueDropdownButton icon-left="settings_backup_restore">Backup and Restore Settings</VueDropdownButton>
            </VueDropdown>
          </div>
        </div>
      </div>
      <div class="row borderOut">
        <h2>showDevice</h2>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      boolean: false,
      string: '',
    }
  },
}
</script>

<style lang="stylus">
@import '~@style';

.mainDevice {
  display: flex;
}

.sideDevice {
  // flex: auto 0 0;
  // background: $vue-ui-color-light-neutral;
  // overflow-y: auto;
  // border: 1px dashed #000;
}

.drawDevice {
  // flex: 100% 1 1;
  // width: 0;
  // overflow: auto;
  // border: 1px dashed #000;
}

.borderOut {
  border: 1px dashed #000;
}

.marginCenter {
  margin: 0 auto;
}

.row {
  display: grid;
  // grid-template-columns: repeat(auto-fit, 60px);
  grid-gap: 24px;
  margin-bottom: @grid-gap;
}

.color {
  background: $vue-ui-color-light-neutral;

  .color-preview {
    margin: 0 auto;
    width: 60px;
    height: @width;
    border-radius: 50%;
  }

  .label {
    opacity: 0.5;
    font-size: 12px;
    margin-top: 4px;
    text-align: center;
  }

  for type, typeIndex in 'gray' primary accent danger warning info {
    for i in (1 .. 9) {
      &.color-{type}-{i}00 {
        .color-preview {
          background: lookup('$vue-ui-' + type + '-' + i + '00');
        }
      }
    }
  }
}
</style>

