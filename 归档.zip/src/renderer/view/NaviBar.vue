<template>
  <div id="navibar">
    <router-link to="/">Home</router-link>|
    <router-link to="/about">About</router-link>
    <div class="vue-ui-spacer" />
    <VueGroup v-model="theme" class="inline">
      <VueGroupButton value="default">Default</VueGroupButton>
      <VueGroupButton value="dark">Dark</VueGroupButton>
      <VueGroupButton value="high-contrast">High contrast</VueGroupButton>
    </VueGroup>
  </div>
</template>

<script>

export default {
  computed: {
    theme: {
      get () { return this.$store.state.theme },
      set (v) { this.$store.commit('SWITCH_THEME', v) },
    },
  },
  mounted () {
    this.$store.commit('SWITCH_THEME', localStorage.getItem('vue-ui:theme') || 'default')
  },
}

</script>


<style lang="stylus">
@import '~@style';

#navibar {
  padding: 12px 24px;
  border-bottom: solid 1px $vue-ui-color-light-neutral;
  h-box();

  .vue-ui-dark-mode & {
    border-bottom-color: $vue-ui-color-dark;
  }

  a {
    color: $vue-ui-color-dark;
    display: inline-block;
    padding: 0 6px;

    .vue-ui-dark-mode & {
      color: $vue-ui-color-light-neutral;
    }

    &.router-link-exact-active {
      color: $vue-ui-color-primary;
    }
  }
}
</style>


