<template>
  <div class="content">
    <span>dashboard</span>
  </div>
</template>