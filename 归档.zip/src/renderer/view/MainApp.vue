<template>
  <div id="app-wrapper">
    <NaviBar class="navibar-container" />
    <div class="mainapp-wrapper">
      <SideBar class="sidebar-container" />
      <router-view class="mainapp-container" />
    </div>
  </div>
</template>

<script>
import NaviBar from '@/view/NaviBar'
import SideBar from '@/view/SideBar'

export default {
  name: 'MainApp',
  components: {    NaviBar, SideBar,
  },
  computed: {
    cmain: function () {
      return this.$store.state.Counter.main    }
  },
  data () {
    return {
      path: this.$route.path,
    }
  },
  methods: {
    open (link) {
      this.$store.commit('INCREMENT_MAIN_COUNTER')
      this.$electron.shell.openExternal(link)
    }
  }
}
</script>

<style lang="scss">
@import "~@/styles/mixin.scss";
</style>

<style lang="stylus">
@import '~@style';

html, body, #app-wrapper {
  height: 100%;
}

#app-wrapper {
  v-box();
}

.navibar-container {
}

.mainapp-wrapper {
  display: flex;
}

.sidebar-container {
  flex: auto 0 0;
  background: $vue-ui-color-light-neutral;
  overflow-y: auto;

  .vue-ui-dark-mode & {
    background: $vue-ui-color-darker;
  }
}

.mainapp-container {
  flex: 100% 1 1;
  width: 0;
  overflow: auto;
}
</style>


