import Vue from 'vue'
import axios from 'axios'

import App from './App'
import router from './router'
import store from './store'

// npm i -S @vue/ui
// import Vue from 'vue'
import VueUi from '@vue/ui'
import '@vue/ui/dist/vue-ui.css'
Vue.use(VueUi)

if (!process.env.IS_WEB) Vue.use(require('vue-electron'))
Vue.http = Vue.prototype.$http = axios
Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  components: { App },
  router,
  store,
  template: '<App/>'
}).$mount('#app')
