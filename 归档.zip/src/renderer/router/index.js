import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const demos = [
  {
    path: '/dashboard',
    component: () => import('@/view/dashboard/index'),
    name: 'dashboard',
    meta: { label: 'upload', title: 'upload' }
  },
  {
    path: '/order/down',
    component: () => import('@/view/order/Down'),
    name: 'down',
    meta: { label: 'down', title: 'down' }
  },
  {
    path: '/order/upload',
    component: () => import('@/view/order/Upload'),
    name: 'upload',
    meta: { label: 'upload', title: 'upload' }
  }
]

export default new Router({
  routes: [

    {
      path: '/',
      redirect: '/dashboard',
      component: require('@/view/Mainapp').default,
      name: 'MainApp',
      children: demos
    },

    {
      path: '/order',
      redirect: '/order/down',
      component: () => import('@/view/Mainapp'),
      name: 'order',
      children: demos
    },

    {
      path: '/landing',
      name: 'landing-page',
      component: require('@/components/LandingPage').default
    },
    {
      path: '*',
      redirect: '/'
    }
  ]
})
